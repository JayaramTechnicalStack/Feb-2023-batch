package com.org.emp;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class EmployeeServlet extends GenericServlet {

	@Override
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		 
		 String employeeId = request.getParameter("empId"); // String employeeId=1
		 int empno = Integer.parseInt(employeeId);
		
		 String employeeName =request.getParameter("empName");
		 
		 String salary = request.getParameter("salary");
		 
		 double empsalary = Double.parseDouble(salary);
		 
		 String adrress = request.getParameter("empAddr");
		 
			
			pw.println("employeeId is :" + empno);
			pw.println("<br/>");
			pw.println("employeeName is :" + employeeName);
			pw.println("<br/>");
			pw.println("salary is :" + empsalary);
			pw.println("<br/>");
			pw.println("adrress is :" + adrress);
			pw.println("<br/>");
			 
		 
		 // jdbc code 
		 
		 try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/feb2023","root", "root");
			String sqlQuery ="insert into employee value(?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(sqlQuery);
			ps.setInt(1, empno);
			ps.setString(2, employeeName);
			ps.setDouble(3, empsalary);
			ps.setString(4, adrress);
			int result = 0;
			try {
				result = ps.executeUpdate();
			}catch (SQLException e) {
				e.printStackTrace();
			}
			
			if(result>0) {
				pw.println("Employee record is inserted via html page");
			}else {
				pw.println("Employee record is not inserted ");
			}
		 }
		 catch (Exception e) {
			e.printStackTrace();
		}
		 
	}

}
