package com.login.test;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginServlet extends HttpServlet{
	
	
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		resp.setContentType("text/html");  
	    PrintWriter out = resp.getWriter(); 
	    
	    String name=req.getParameter("userName");  // vijay 
	    String password=req.getParameter("userPass"); // hello 
	        
	    String dbName = null;
	    String dbPassword = null;
	    
	    // db logic 
	    try {
	    	
	    Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/feb2023","root", "root");
	    String sqlQuery = "select username , password from user where username =?";
	    PreparedStatement ps = con.prepareStatement(sqlQuery);
	    
	    ps.setString(1, name);
	    ResultSet rs = ps.executeQuery();
	    while (rs.next()) {
	    	dbName = rs.getString(1); // vijay
	    	dbPassword = rs.getString(2); // hello
	    }
	    }catch (Exception e) {
			e.printStackTrace();
		}
	    
	    if(name.equalsIgnoreCase(dbName) && password.equals(dbPassword)){ 
	    	
	        RequestDispatcher rd=req.getRequestDispatcher("servlet2");  
	        rd.forward(req, resp);  
	    }  
	    else{  
	        out.print("Sorry UserName or Password Wrong!");  
	        RequestDispatcher rd=req.getRequestDispatcher("/index.html");  
	        rd.include(req, resp);  
	                      
	        }  
		
	    out.println("<html>");
	    out.println("<body>");
	    out.println("<form action ='servlet'>");
	    out.println("<html>");
	}

}
