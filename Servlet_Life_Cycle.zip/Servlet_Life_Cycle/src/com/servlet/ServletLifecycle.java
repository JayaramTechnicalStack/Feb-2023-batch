package com.servlet;

import java.io.IOException;

import javax.servlet.GenericServlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;


public class ServletLifecycle extends GenericServlet {

  
	public void init(ServletConfig config) throws ServletException {
		System.out.println("Servlet Config object is created : Serv1");
		
	}
	

	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		
		System.out.println("inside Service Method :Serv1  ");

	}
	
	
	public void destroy() {
		
		System.out.println("Object is destroyed : Srv1");
	}

	
	public ServletConfig getServletConfig() {
		return null;
	}

	
	public String getServletInfo() {
		
		return null; 
	}

	
	

}
